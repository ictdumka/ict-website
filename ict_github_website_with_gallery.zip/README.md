# ICT Computer Centre Website with Gallery

This version includes a simple photo gallery.